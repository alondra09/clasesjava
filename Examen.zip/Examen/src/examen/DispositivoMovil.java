package examen;

public abstract class DispositivoMovil
{
    public DispositivoMovil()
    {
        
    }
    
    public abstract void Apagar();
    public abstract void Encender();
}