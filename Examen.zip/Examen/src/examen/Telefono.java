package examen;

public class Telefono extends DispositivoMovil
{
    private float precio;
    private String marca;
    private int modelo;

    public Telefono(float precio,String marca,int modelo)
    {
        this.precio=precio;
        this.marca=marca;
        this.modelo=modelo;
    }
    
    public void hacerLlamada()
    {
        System.out.println("El telefono hace llamada");
    }
    public void colgarLlamada()
    {
        System.out.println("El telefono cuelga llamada");
    }

    @Override
    public void Apagar()
    {
        System.out.println("El telefono esta apagado");
    }
    @Override
    public void Encender()
    {
        System.out.println("El telefono esta encendido");
    }

    public float getPrecio()
    {
        return precio;
    }
    public void setPrecio(float precio)
    {
        this.precio=precio;
    }
    public String getMarca()
    {
        return marca;
    }
    public void setMarca(String marca)
    {
        this.marca=marca;
    }
    public int getModelo()
    {
        return modelo;
    }
    public void setModelo(int modelo)
    {
        this.modelo=modelo;
    }    
}