package examen;

public class Radio extends DispositivoMovil
{
    private String marca,color;
    private int modelo;

    public Radio(String marca, String color, int modelo)
    {
        this.marca=marca;
        this.color=color;
        this.modelo=modelo;
    }
    
    @Override
    public void Apagar()
    {
        System.out.println("El radio esta apagado");
    }
    @Override
    public void Encender()
    {
        System.out.println("El radio esta encendido");
    }

    public String getMarca()
    {
        return marca;
    }
    public void setMarca(String marca)
    {
        this.marca=marca;
    }
    public String getColor()
    {
        return color;
    }
    public void setColor(String color)
    {
        this.color=color;
    }
    public int getModelo()
    {
        return modelo;
    }
    public void setModelo(int modelo)
    {
        this.modelo=modelo;
    }
}