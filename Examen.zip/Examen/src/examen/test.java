package examen;

public class test
{
    public static void main(String args[])
    {
        String banda;
        
        Telefono tel[]=new Telefono[3];
        Radio rad[]=new Radio[3];
        
        //llenado telefono
        for(int i=0;i<3;i++)
        {
            float precio=2500+i;
            String marca="Marca "+i;
            int modelo=i;
            tel[i]=new Telefono(precio,marca,modelo);
        }
        //impresion telefono
        System.out.println("Telefonos\n");
        for(int i=0;i<3;i++)
        {
            System.out.println(tel[i].getPrecio());
            System.out.println(tel[i].getMarca());
            System.out.println(tel[i].getModelo());
        }
        //llenado radio
        for(int i=0;i<3;i++)
        {
            String marca="Marca "+i;
            String color="Color "+i;
            int modelo=i;
            rad[i]=new Radio(marca,color,modelo);
        }
        //impresion radio
        System.out.println("\nRadios\n");
        for(int i=0;i<3;i++)
        {
            System.out.println(rad[i].getMarca());
            System.out.println(rad[i].getColor());
            System.out.println(rad[i].getModelo());
        }
    } 
}